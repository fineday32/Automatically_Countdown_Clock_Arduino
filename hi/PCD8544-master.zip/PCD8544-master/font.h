#ifndef FONT_H
#define FONT_H

enum {
	FONT_WIDTH = 5,
	ASCII_SPC = 0x20,
};

extern const char font5x8[][5];

#endif
